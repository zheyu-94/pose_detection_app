import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart'; // 🌟 記得引入 Firestore
import 'training_screen.dart';

class StartWorkoutScreen extends StatefulWidget {
  const StartWorkoutScreen({super.key});

  @override
  State<StartWorkoutScreen> createState() => _StartWorkoutScreenState();
}

class _StartWorkoutScreenState extends State<StartWorkoutScreen> {
  // 🌟 1. 狀態變數：改成接收 Firebase 格式的 Map 陣列，並加入日期與載入狀態
  List<Map<String, dynamic>> _todayWorkout = [];
  DateTime _selectedDate = DateTime.now();
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchWorkoutForDate(); // 畫面初始化時，抓取今天的菜單
  }

  // 🌟 2. 從 Firebase 抓取指定日期的菜單
  Future<void> _fetchWorkoutForDate() async {
    setState(() {
      _isLoading = true;
    });

    String dateString = "${_selectedDate.year}-${_selectedDate.month.toString().padLeft(2, '0')}-${_selectedDate.day.toString().padLeft(2, '0')}";

    try {
      DocumentSnapshot doc = await FirebaseFirestore.instance
          .collection('users')
          .doc('test_user') // ⚠️ 如果有做登入，請換成真實的 UID
          .collection('daily_workouts')
          .doc(dateString)
          .get();

      if (doc.exists && doc.data() != null) {
        // 如果當天有菜單，讀取出來並轉型
        List<dynamic> exercises = doc.get('exercises');
        setState(() {
          _todayWorkout = List<Map<String, dynamic>>.from(exercises);
        });
      } else {
        // 當天沒排菜單，清空列表
        setState(() {
          _todayWorkout = [];
        });
      }
    } catch (e) {
      debugPrint("❌ 讀取失敗: $e");
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // 🌟 3. 將最新的排序或刪除結果，同步更新(覆蓋)回 Firebase
  Future<void> _updateWorkoutInFirebase() async {
    String dateString = "${_selectedDate.year}-${_selectedDate.month.toString().padLeft(2, '0')}-${_selectedDate.day.toString().padLeft(2, '0')}";

    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc('test_user')
          .collection('daily_workouts')
          .doc(dateString)
          .update({
        'exercises': _todayWorkout, // 直接用新的陣列覆蓋舊的
      });
      debugPrint("✅ 雲端資料同步更新成功！");
    } catch (e) {
      debugPrint("❌ 更新失敗: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        title: const Text('🏃 開始運動', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 🌟 4. 加入與菜單規劃相同的「選擇日期」按鈕
            GestureDetector(
              onTap: () async {
                final DateTime? picked = await showDatePicker(
                  context: context,
                  initialDate: _selectedDate,
                  firstDate: DateTime(2023),
                  lastDate: DateTime(2030),
                  builder: (context, child) {
                    return Theme(
                      data: Theme.of(context).copyWith(
                        colorScheme: const ColorScheme.dark(
                          primary: Colors.blueAccent,
                          onPrimary: Colors.white,
                          surface: Color(0xFF1E1E1E),
                          onSurface: Colors.white,
                        ),
                      ),
                      child: child!,
                    );
                  },
                );
                if (picked != null && picked != _selectedDate) {
                  setState(() {
                    _selectedDate = picked;
                  });
                  // 🌟 選完日期後，重新去 Firebase 抓資料！
                  _fetchWorkoutForDate();
                }
              },
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 16),
                margin: const EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                  color: Colors.blueAccent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: Colors.blueAccent.withOpacity(0.5)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('📅 訓練日期', style: TextStyle(color: Colors.white, fontSize: 16)),
                    Text(
                      "${_selectedDate.year}-${_selectedDate.month.toString().padLeft(2, '0')}-${_selectedDate.day.toString().padLeft(2, '0')}",
                      style: const TextStyle(color: Colors.blueAccent, fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),

            const Text(
              '訓練清單',
              style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 5),
            const Text(
              '💡 長按右側圖示可上下拖曳調整順序，左滑可刪除動作。',
              style: TextStyle(color: Colors.grey, fontSize: 14),
            ),
            const SizedBox(height: 15),

            // 🌟 5. 根據載入狀態顯示不同畫面
            Expanded(
              child: _isLoading
                  ? const Center(child: CircularProgressIndicator(color: Colors.blueAccent))
                  : _todayWorkout.isEmpty
                  ? const Center(
                child: Text(
                  '今天沒有安排菜單喔！\n快去「菜單規劃」新增吧💪',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey, fontSize: 16, height: 1.5),
                ),
              )
                  : ReorderableListView.builder(
                itemCount: _todayWorkout.length,
                onReorder: (int oldIndex, int newIndex) {
                  setState(() {
                    if (newIndex > oldIndex) {
                      newIndex -= 1;
                    }
                    final item = _todayWorkout.removeAt(oldIndex);
                    _todayWorkout.insert(newIndex, item);
                  });
                  // 🌟 拖曳完成後，同步更新 Firebase
                  _updateWorkoutInFirebase();
                },
                itemBuilder: (context, index) {
                  // 🌟 改從 Map 中讀取資料
                  final exercise = _todayWorkout[index];
                  final exerciseName = exercise['name'] ?? '未知動作';
                  final sets = exercise['sets'] ?? 3;
                  final reps = exercise['reps'] ?? 12;

                  return Dismissible(
                    // ⚠️ Key 必須獨一無二，避免名字重複時報錯
                    key: Key('${exerciseName}_$index'),
                    direction: DismissDirection.endToStart,
                    background: Container(
                      alignment: Alignment.centerRight,
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      decoration: BoxDecoration(
                        color: Colors.redAccent,
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: const Icon(Icons.delete, color: Colors.white),
                    ),
                    onDismissed: (direction) {
                      setState(() {
                        _todayWorkout.removeAt(index);
                      });
                      // 🌟 刪除後，同步更新 Firebase！
                      _updateWorkoutInFirebase();

                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('$exerciseName 已移除'), duration: const Duration(seconds: 2)),
                      );
                    },
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      decoration: BoxDecoration(
                        color: Colors.grey[900],
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(color: Colors.grey[800]!),
                      ),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: Colors.blueAccent.withOpacity(0.2),
                          child: Text('${index + 1}', style: const TextStyle(color: Colors.blueAccent, fontWeight: FontWeight.bold)),
                        ),
                        title: Text(exerciseName, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                        subtitle: Text('建議組數: $sets組 x $reps下', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                        trailing: ReorderableDragStartListener(
                          index: index,
                          child: const Icon(Icons.drag_handle, color: Colors.white54, size: 30),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),

            // --- 底部開始按鈕 ---
            const SizedBox(height: 15),
            SizedBox(
              width: double.infinity,
              height: 60,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.play_circle_fill, color: Colors.white, size: 28),
                label: const Text('進入第一項訓練', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _todayWorkout.isEmpty ? Colors.grey[800] : Colors.blueAccent,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                ),
                onPressed: _todayWorkout.isEmpty
                    ? null
                    : () {
                  // 🌟 抓取清單中的第一個動作名稱
                  String firstExerciseName = _todayWorkout.first['name'];

                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => TrainingScreen(exerciseName: firstExerciseName),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}